' DetailsScreen logic. Populates itself whenever HomeScene assigns a new
' `item`, reads the title's saved bookmark, and turns button presses into
' a playRequest for HomeScene: { item: <ContentNode>, startAt: <seconds> }.

sub init()
    m.poster = m.top.findNode("poster")
    m.titleLabel = m.top.findNode("titleLabel")
    m.metaLabel = m.top.findNode("metaLabel")
    m.descriptionLabel = m.top.findNode("descriptionLabel")
    m.lengthLabel = m.top.findNode("lengthLabel")
    m.resumeLabel = m.top.findNode("resumeLabel")
    m.buttons = m.top.findNode("buttons")
    m.buttons.observeField("buttonSelected", "onButtonSelected")
    m.buttonActions = []
    m.bookmark = 0
    m.currentItem = invalid
end sub

sub onItemChanged()
    item = m.top.item
    if item = invalid then return
    m.currentItem = item

    m.poster.uri = item.HDPosterUrl
    m.titleLabel.text = item.title
    m.descriptionLabel.text = item.description
    m.metaLabel.text = AfCategoryName(item.pillar) + "  ·  " + AfFormatTime(item.length)
    m.lengthLabel.text = "Length: " + AfFormatTime(item.length)

    m.bookmark = AfGetBookmark(item.id)
    labels = []
    actions = []
    if m.bookmark > 0
        labels.push("Resume from " + AfFormatTime(m.bookmark))
        actions.push("resume")
        labels.push("Play from Beginning")
        actions.push("restart")
        m.resumeLabel.text = "You left off at " + AfFormatTime(m.bookmark) + "."
    else
        labels.push("Play")
        actions.push("restart")
        m.resumeLabel.text = ""
    end if
    m.buttonActions = actions
    m.buttons.buttons = labels
    m.buttons.setFocus(true)
end sub

sub onButtonSelected()
    index = m.buttons.buttonSelected
    if index < 0 or index >= m.buttonActions.count() then return
    if m.currentItem = invalid then return
    startAt = 0
    if m.buttonActions[index] = "resume" then startAt = m.bookmark
    m.top.playRequest = { item: m.currentItem, startAt: startAt }
end sub

function onKeyEvent(key as String, press as Boolean) as Boolean
    if press and key = "back"
        m.top.closeSignal = m.top.closeSignal + 1
        return true
    end if
    return false
end function

function AfCategoryName(pillar as String) as String
    if pillar = "sleep" then return "Sleep"
    if pillar = "focus" then return "Focus"
    if pillar = "study" then return "Study"
    return pillar
end function
