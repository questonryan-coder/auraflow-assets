' ---------------------------------------------------------------------------
' AuraFlow - entry point.
'
' Deep linking (certification 5.1) and Direct to Play (5.2):
'   * Launch arguments arrive here as `args` (contentId + mediaType) and
'     are handed to HomeScene through its launch* interface fields.
'   * Deep links that arrive while the channel is already running come in
'     as roInput events (manifest sets supports_input_launch=1) and are
'     handed over through the input* fields the same way.
' HomeScene owns everything after that: if the feed is still loading, the
' requested id is held and honoured as soon as the catalog arrives.
' ---------------------------------------------------------------------------

sub Main(args as Dynamic)
    screen = CreateObject("roSGScreen")
    port = CreateObject("roMessagePort")
    screen.setMessagePort(port)

    scene = screen.CreateScene("HomeScene")
    screen.show()

    if args <> invalid
        scene.launchContentId = AfArgString(args, "contentId")
        scene.launchMediaType = AfArgString(args, "mediaType")
    end if

    input = CreateObject("roInput")
    input.setMessagePort(port)

    while true
        msg = wait(0, port)
        msgType = type(msg)
        if msgType = "roSGScreenEvent"
            if msg.isScreenClosed() then return
        else if msgType = "roInputEvent"
            if msg.isInput()
                info = msg.getInfo()
                if info <> invalid
                    scene.inputContentId = AfArgString(info, "contentId")
                    scene.inputMediaType = AfArgString(info, "mediaType")
                end if
            end if
        end if
    end while
end sub

' Safe string lookup in a launch/input argument array: "" when absent.
function AfArgString(aa as Dynamic, key as String) as String
    if aa = invalid then return ""
    value = aa[key]
    if value = invalid then return ""
    return value.toStr()
end function
