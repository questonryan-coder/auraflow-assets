' FeedTask thread function. Runs off the render thread: the network fetch
' and JSON parse happen here, and only the finished ContentNode tree is
' handed back through the `content` field.

sub RunFeedTask()
    url = m.top.feedUrl
    if url = ""
        m.top.error = "No feed address is configured."
        return
    end if

    transfer = CreateObject("roURLTransfer")
    transfer.setUrl(url)
    transfer.setCertificatesFile("common:/certs/ca-bundle.crt")
    transfer.initClientCertificates()

    raw = transfer.getToString()
    if raw = ""
        m.top.error = "The AuraFlow catalog could not be loaded. Check the connection and try again."
        return
    end if

    data = ParseJSON(raw)
    if data = invalid or data.items = invalid or data.categories = invalid
        m.top.error = "The AuraFlow catalog was not in the expected format."
        return
    end if

    ' One row node per category, in the order the feed declares them.
    root = CreateObject("roSGNode", "ContentNode")
    root.title = "AuraFlow"
    rowsByCategory = {}
    for each category in data.categories
        row = root.createChild("ContentNode")
        row.title = category.title
        rowsByCategory[category.id] = row
    end for

    for each entry in data.items
        row = rowsByCategory[entry.category]
        if row <> invalid
            item = row.createChild("ContentNode")
            AfFillItem(item, entry)
        end if
    end for

    ' Drop any category row that ended up empty.
    for i = root.getChildCount() - 1 to 0 step -1
        if root.getChild(i).getChildCount() = 0
            root.removeChildIndex(i)
        end if
    end for

    m.top.content = root
end sub

sub AfFillItem(item as Object, entry as Object)
    item.id = entry.id
    item.title = entry.title
    item.description = entry.description
    item.contentType = "movie"
    item.HDPosterUrl = entry.posterUrl
    item.SDPosterUrl = entry.posterUrl
    item.url = entry.streamUrl
    item.streamFormat = entry.streamFormat
    item.length = entry.durationSeconds
    ' Trick-play thumbnails (certification 4.7). bifUrl/sdBifUrl are
    ' standard content-metadata fields; addField is called first so the
    ' assignment is safe whether or not the node predeclares them.
    item.addField("bifUrl", "string", false)
    item.addField("sdBifUrl", "string", false)
    item.addField("pillar", "string", false)
    if entry.bifUrl <> invalid
        item.bifUrl = entry.bifUrl
        item.sdBifUrl = entry.bifUrl
    end if
    item.pillar = entry.category
    item.playStart = 0
end sub
