' ---------------------------------------------------------------------------
' AuraFlow channel configuration.
'
' MEDIA_BASE_URL is the single place the channel's public media host is
' defined. It is a PLACEHOLDER: it must be replaced with the real public
' base URL of the Cloudflare R2 bucket (custom domain or r2.dev URL) once
' that account exists. feed/generate_feed.py carries the identical
' constant (BASE_URL) so the published feed and the channel never drift:
' replace the same string in both files.
'
' Layout expected under MEDIA_BASE_URL:
'   /feed.json                content feed (see feed/generate_feed.py)
'   /posters/<slug>.jpg       640x360 poster per title
'   /hls/<slug>/index.m3u8    HLS stream per title
'   /bif/<slug>.bif           BIF trick-play file per title
' ---------------------------------------------------------------------------

function AfConfig() as Object
    base = "https://questonryan-coder.github.io/auraflow-assets/roku-test"  ' PLACEHOLDER - not a real URL
    return {
        mediaBaseUrl: base,
        feedUrl: "https://questonryan-coder.github.io/auraflow-assets/roku-test/test-feed.json",
        bookmarkSection: "auraflow",
        bookmarkPrefix: "bm_",
        ' A saved position counts as a bookmark only after this many seconds,
        ' and is discarded this many seconds before the end of a title.
        bookmarkMinSeconds: 45,
        bookmarkEndMarginSeconds: 20
    }
end function
