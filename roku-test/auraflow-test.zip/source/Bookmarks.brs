' ---------------------------------------------------------------------------
' Playback bookmarks (certification 4.10: resume is mandatory for VOD
' longer than 15 minutes, stored for at least 30 days).
'
' Positions live in the channel's own registry section, which persists
' across sessions and reboots until the channel is removed - comfortably
' beyond the 30-day floor. One small string key per title:
'   "bm_" + contentId  ->  position in whole seconds
' ---------------------------------------------------------------------------

function AfBookmarkKey(contentId as String) as String
    return AfConfig().bookmarkPrefix + contentId
end function

' Returns the saved position in seconds, or 0 when there is no usable
' bookmark for the title.
function AfGetBookmark(contentId as String) as Integer
    if contentId = "" then return 0
    section = CreateObject("roRegistrySection", AfConfig().bookmarkSection)
    key = AfBookmarkKey(contentId)
    if section.exists(key)
        return section.read(key).toInt()
    end if
    return 0
end function

' Saves a position. Positions too close to the start are ignored;
' positions at or past the end margin clear the bookmark instead, so a
' finished title starts from the beginning next time.
sub AfSaveBookmark(contentId as String, position as Integer, duration as Integer)
    if contentId = "" then return
    cfg = AfConfig()
    if duration > 0 and position >= duration - cfg.bookmarkEndMarginSeconds
        AfClearBookmark(contentId)
        return
    end if
    if position <= cfg.bookmarkMinSeconds then return
    section = CreateObject("roRegistrySection", cfg.bookmarkSection)
    section.write(AfBookmarkKey(contentId), position.toStr())
    section.flush()
end sub

sub AfClearBookmark(contentId as String)
    if contentId = "" then return
    section = CreateObject("roRegistrySection", AfConfig().bookmarkSection)
    key = AfBookmarkKey(contentId)
    if section.exists(key)
        section.delete(key)
        section.flush()
    end if
end sub

' "1:23:45" for an hour-plus position, "23:45" below an hour.
function AfFormatTime(totalSeconds as Integer) as String
    if totalSeconds < 0 then totalSeconds = 0
    hours = totalSeconds \ 3600
    minutes = (totalSeconds - hours * 3600) \ 60
    seconds = totalSeconds - hours * 3600 - minutes * 60
    mm = minutes.toStr()
    ss = seconds.toStr()
    if len(ss) < 2 then ss = "0" + ss
    if hours > 0
        if len(mm) < 2 then mm = "0" + mm
        return hours.toStr() + ":" + mm + ":" + ss
    end if
    return mm + ":" + ss
end function
