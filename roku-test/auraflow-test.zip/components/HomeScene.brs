' HomeScene logic: loads the catalog through FeedTask, drives the grid,
' routes selections to the details overlay, routes play requests to the
' player overlay, and honours deep links (launch args and roInput) -
' including links that arrive before the feed has finished loading.

sub init()
    m.rows = m.top.findNode("rows")
    m.loadingLabel = m.top.findNode("loadingLabel")
    m.errorLabel = m.top.findNode("errorLabel")
    m.details = m.top.findNode("details")
    m.player = m.top.findNode("player")

    m.itemById = {}
    m.pendingContentId = ""
    m.feedReady = false
    m.lastSelection = [0, 0]
    m.playerFromDetails = false

    m.rows.observeField("rowItemSelected", "onItemSelected")
    m.details.observeField("playRequest", "onPlayRequest")
    m.details.observeField("closeSignal", "onDetailsClosed")
    m.player.observeField("closeSignal", "onPlayerClosed")

    m.top.observeField("launchContentId", "onDeepLinkField")
    m.top.observeField("inputContentId", "onDeepLinkField")

    m.feedTask = CreateObject("roSGNode", "FeedTask")
    m.feedTask.feedUrl = AfConfig().feedUrl
    m.feedTask.observeField("content", "onFeedContent")
    m.feedTask.observeField("error", "onFeedError")
    m.feedTask.functionName = "RunFeedTask"
    m.feedTask.control = "RUN"
end sub

' --- Feed ---------------------------------------------------------------

sub onFeedContent()
    content = m.feedTask.content
    if content = invalid then return
    m.feedReady = true

    ' Index every title by id for deep-link lookups.
    for each row in content.getChildren(-1, 0)
        for each item in row.getChildren(-1, 0)
            m.itemById[item.id] = item
        end for
    end for

    m.rows.content = content
    m.loadingLabel.visible = false
    m.errorLabel.visible = false
    m.rows.visible = true
    m.rows.setFocus(true)

    if m.pendingContentId <> ""
        id = m.pendingContentId
        m.pendingContentId = ""
        AfOpenDeepLink(id)
    end if
end sub

sub onFeedError()
    m.loadingLabel.visible = false
    m.errorLabel.text = m.feedTask.error
    m.errorLabel.visible = true
end sub

' --- Grid ---------------------------------------------------------------

sub onItemSelected()
    selection = m.rows.rowItemSelected
    if selection = invalid or selection.count() < 2 then return
    m.lastSelection = selection
    item = m.rows.content.getChild(selection[0]).getChild(selection[1])
    if item = invalid then return
    m.details.item = item
    m.details.visible = true
    m.details.setFocus(true)
end sub

' --- Details / player routing -------------------------------------------

sub onPlayRequest()
    request = m.details.playRequest
    if request = invalid or request.item = invalid then return
    m.playerFromDetails = true
    AfStartPlayer(request.item, request.startAt)
end sub

sub onDetailsClosed()
    m.details.visible = false
    m.rows.visible = true
    m.rows.jumpToRowItem = m.lastSelection
    m.rows.setFocus(true)
end sub

sub onPlayerClosed()
    m.player.visible = false
    if m.playerFromDetails
        m.playerFromDetails = false
        m.details.visible = true
        m.details.setFocus(true)
    else
        m.rows.visible = true
        m.rows.jumpToRowItem = m.lastSelection
        m.rows.setFocus(true)
    end if
end sub

sub AfStartPlayer(item as Object, startAt as Integer)
    m.details.visible = false
    m.rows.visible = false
    m.player.startPosition = startAt
    m.player.item = item
    m.player.visible = true
    m.player.setFocus(true)
end sub

' --- Deep linking ---------------------------------------------------------

sub onDeepLinkField()
    id = m.top.launchContentId
    if id = "" then id = m.top.inputContentId
    if id = "" then return
    ' Consume both fields so the same link is not handled twice.
    m.top.launchContentId = ""
    m.top.inputContentId = ""
    if m.feedReady
        AfOpenDeepLink(id)
    else
        m.pendingContentId = id
    end if
end sub

' Direct to Play: a deep link starts playback immediately, resuming from
' the saved bookmark when one exists.
sub AfOpenDeepLink(contentId as String)
    item = m.itemById[contentId]
    if item = invalid then return
    m.playerFromDetails = false
    AfStartPlayer(item, AfGetBookmark(contentId))
end sub
