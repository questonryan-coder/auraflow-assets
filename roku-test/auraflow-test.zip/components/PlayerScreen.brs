' PlayerScreen logic.
'
' Bookmarks (certification 4.10): the position is written to the registry
' every 10 seconds while a title plays, again whenever playback is left,
' and cleared when a title plays to its end. Starting a title sets the
' content node's playStart field, which is where the Video node begins.

sub init()
    m.video = m.top.findNode("video")
    m.timer = m.top.findNode("bookmarkTimer")
    m.video.observeField("state", "onVideoState")
    m.timer.observeField("fire", "onBookmarkTick")
    m.currentItem = invalid
end sub

sub onItemChanged()
    item = m.top.item
    if item = invalid then return
    m.currentItem = item
    item.playStart = m.top.startPosition
    m.video.content = item
    m.video.control = "play"
    m.timer.control = "start"
    m.video.setFocus(true)
end sub

sub onBookmarkTick()
    AfPersistPosition()
end sub

sub onVideoState()
    state = m.video.state
    if state = "finished"
        if m.currentItem <> invalid then AfClearBookmark(m.currentItem.id)
        AfClose()
    else if state = "error"
        AfPersistPosition()
        AfClose()
    end if
end sub

sub AfPersistPosition()
    if m.currentItem = invalid then return
    position = m.video.position
    if position <= 0 then return
    AfSaveBookmark(m.currentItem.id, int(position), m.currentItem.length)
end sub

sub AfClose()
    m.timer.control = "stop"
    m.video.control = "stop"
    m.top.closeSignal = m.top.closeSignal + 1
end sub

function onKeyEvent(key as String, press as Boolean) as Boolean
    if press and key = "back"
        AfPersistPosition()
        AfClose()
        return true
    end if
    return false
end function
